<?php

require 'app/bootstrap.php';

// In reality, we'd be using proper routing
// with a PHP routing solution.
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die();
}

$delete = $db->prepare("UPDATE users SET active = 0 WHERE id = :user_id");

$delete->execute([
    'user_id' => $_SESSION['user_id'],
]);