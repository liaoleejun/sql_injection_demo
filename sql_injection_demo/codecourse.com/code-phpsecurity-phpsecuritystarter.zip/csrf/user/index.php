<?php

require 'app/bootstrap.php';

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Form</title>
    </head>
    <body>
        <form action="delete.php" method="post">
            <input type="submit" value="Delete my account">
            <input type="hidden" name="_token" value="<?php echo $_SESSION['_token']; ?>">
        </form>
    </body>
</html>
